var indexSectionsWithContent =
{
  0: "fk",
  1: "fk"
};

var indexSectionNames =
{
  0: "all",
  1: "classes"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures"
};

