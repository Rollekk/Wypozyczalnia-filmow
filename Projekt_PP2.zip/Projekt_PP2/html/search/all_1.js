var searchData=
[
  ['klient',['KLIENT',['../struct_k_l_i_e_n_t.html',1,'']]]
];
